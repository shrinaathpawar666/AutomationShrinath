package tests;

import net.bytebuddy.build.Plugin;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.HomePage;
import testbase.WebTestBase;

public class HomeTest extends WebTestBase {
    public HomePage homePage;

    HomeTest() {
        super();
    }

    @BeforeMethod
    public void beforeMethod() {
        initialization();
        homePage = new HomePage();
    }

    @Test(priority = 1)
    public void verifyDropDown() {
        SoftAssert softAssert = new SoftAssert();
        homePage.selectDropDown(prop.getProperty("book"));
        softAssert.assertEquals(homePage.getTitleOfCurrentPage(), "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in", "Title should be match");
        softAssert.assertAll();
    }

    @Test(priority = 2)
    public void verifyCheckBox() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        homePage.searchTextInTextBox(prop.getProperty("bookName"));
        softAssert.assertTrue(homePage.elementToBeDisplayed(), "Element should be selected");
        softAssert.assertAll();
    }

    @Test(priority = 3)
    public void verifyMouseHoverAction() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        homePage.mouseHoverAction();
        softAssert.assertTrue(true, "MouseHover Action should be performed");
        Thread.sleep(2000);
        softAssert.assertAll();
    }

    @Test(priority = 4)
    public void verifyScrollUpDownPage() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        homePage.scrollDownPageByPixel();
        Thread.sleep(2000);
        homePage.scrollUpPageByPixel();
        Thread.sleep(2000);
        softAssert.assertAll();
    }
    @Test(priority = 4)
    public void verifyGetWindowHandles() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        homePage.clickOnFacebookBtn();
        homePage.scrollUpPageByPixel();
        homePage.getAllWindowHandles();
        Thread.sleep(3000);
        softAssert.assertTrue(true, "GetWindowHandles action should be performed");
        softAssert.assertAll();
    }
    @AfterMethod
    public void afterMethod() {
        driver.close();
    }
}


